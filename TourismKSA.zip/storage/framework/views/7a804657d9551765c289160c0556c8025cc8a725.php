<nav class="sidebar sidebar-offcanvas" id="sidebar">

    <ul class="nav">

        <li class="nav-item nav-category">
            <span class="nav-link">Navigation</span>
        </li>
        <li class="nav-item menu-items" style="margin: 5px;">
          <a class="nav-link" href="<?php echo e(url('home')); ?>">
            <span class="menu-icon">
              <i class="mdi mdi-file-document-box"></i>
            </span>
              <span class="menu-title" style="font-size: large">Dashboard</span>
          </a>
      </li>

        <li class="nav-item menu-items" style="margin: 5px;">
            <a class="nav-link" href="<?php echo e(url('add_places_view')); ?>">
              <span class="menu-icon">
                <i class="mdi mdi-file-document-box"></i>
              </span>
                <span class="menu-title" style="font-size: large">Add Places</span>
            </a>
        </li>
        <li class="nav-item menu-items" style="margin: 5px;">
            <a class="nav-link" href="<?php echo e(url('Show_places_view')); ?>">
              <span class="menu-icon">
                <i class="mdi mdi-file-document-box"></i>
              </span>
                <span class="menu-title" style="font-size: large">Show Places</span>
            </a>
        </li>
        <li class="nav-item menu-items" style="margin: 5px;">
            <a class="nav-link" href="<?php echo e(url('ShowAllImages')); ?>">
              <span class="menu-icon">
                <i class="mdi mdi-file-document-box"></i>
              </span>
                <span class="menu-title" style="font-size: large">Show All Images</span>
            </a>
        </li>
    </ul>
</nav>
<?php /**PATH C:\xampp\htdocs\TourismKSA\resources\views/admin/sidebar.blade.php ENDPATH**/ ?>