<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\image;
use App\Models\place;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;

class AdminController extends Controller
{
    //.....admin add a place to the database
    public function add_place(Request $data)
    {

        if(  $place = place::create([
            'name' => $data['name'],
            'location' => $data['location'],
            'GoogleMap' => $data['GoogleMap'],
            'category' => $data['category'],
            'details' => $data['details'],


        ]))
        {
            echo ('added successfully');
            return redirect()->back();
        }
        else{
            echo (' failed');
            return redirect()->back();
        }
    }
    //...............................................
    public function storeImage(Request $request){
        $data1= new image();
        $data1['place_id']= $request['place_id'];
        $data1['place_name']= $request['place_name'];
        if($request->file('url')){
            $file= $request->file('url');
            $filename= date('YmdHi').$file->getClientOriginalName();
            $file-> move(public_path('public/Image'), $filename);
            $data1['url']= 'public/Image/'.$filename;

        }
        $data1->save();


    }
    //.......................................................
    public function delete_place($place_id)
    {

        $whereArray = array('id' => $place_id);

        $query = DB::table('places');
        foreach ($whereArray as $field => $value) {
            $query->where($field, $value);
        }
        if ($query->delete()) {
            return response()->json([
                "message" => "deleted",

            ], 200);
        } else {
            return response()->json([
                "message" => "failed"
            ], 404);
        }
    }
    //..........................
    public function delete_image($image_id)
    {

        $news = image::findOrFail($image_id);
        $image_path = public_path($news['url']);

        if (File::exists($image_path)) {
            File::delete($image_path);
            //unlink($image_path);
        }

        if ($news->delete()) {
            return response()->json([
                "message" => "deleted",

            ], 200);
        } else {
            return response()->json([
                "message" => "failed"
            ], 404);
        }
    }
//.................
    public function get_places(): \Illuminate\Http\JsonResponse
    {
        $query = DB::table('places');
        $places = $query->get();

        $query1 = DB::table('images');
        $images= $query1->get();
        return response()->json([
            "All places_info" => $places,
            "images"=>$images

        ], 200);
    }
//.......................................
    public function get_place_based_id($place_id): \Illuminate\Http\JsonResponse
    {
        $query = DB::table('places');
        $place = $query->where('id', '=', $place_id)
            ->get();
        $query1 = DB::table('images');
        $images= $query1->where('place_id', '=', $place_id)
            ->get();
       // return response()->json($place);
        return response()->json([
            "place_info" => $place,
            "images"=>$images

        ], 200);
    }
//..................................................................get_image
    public function get_image($place_id): \Illuminate\Http\JsonResponse
    {
        $query1 = DB::table('images');
        $images= $query1->where('place_id', '=', $place_id)
            ->select('url')
            ->get();
        return response()->json($images);
    }
    //.................................................
    public function get_places_based_category($category): \Illuminate\Http\JsonResponse
    {
        $query = DB::table('places');
        $places = $query->where('category', '=', $category)
            ->get();
        return response()->json($places);
    }
    //..........................................................
    public function get_categories()
    {
        $query = DB::table('places');
        $categories = $query
            ->select('category')
            ->distinct()
            ->get();

        return response()->json($categories);
    }
}
