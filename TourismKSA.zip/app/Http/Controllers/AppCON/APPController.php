<?php

namespace App\Http\Controllers\AppCON;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class APPController extends Controller
{
    //
}
